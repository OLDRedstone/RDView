<link rel="stylesheet" href="RDView.css">

<div class="RDView" style="--row:9; --column:33; --scale:1;">
	<div class="lines" style="--line-count:4; --cpb:6;"><div>1</div><div>2</div><div>3</div><div>4</div></div>
	<div class="lines" style="--beat: 23; --line-count:2; --cpb:5;"><div>5</div><div>6</div></div>
	<div class="playhead" style="--beat:12;"></div>
	<div class="event rooms" style="--beat:0; --y:1; --event-x:0; --event-y:1;"><div class="condition-true"></div></div>
	<div class="beat" style="--tick:3; --beat:6; --y:1; --swing:0.25; --hold:1;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="tag"></div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--tick:1; --beat:6; --y:7; --interval:3; --delay:0.5;">
		<div class="freezeshot"></div>
		<div class="skipshot"></div>
	</div>
	<div class="beat" style="--tick:1; --beat:3; --y:5; --interval:2;">
		<div class="burnshot"></div>
	</div>
	<div class="beat" style="--tick:2; --beat:0; --y:7; --subdivision:2;">
		<div class="subdivision">
			<div></div>
		</div>
	</div>
	<div class="beat" style="--tick:3; --beat:1; --y:1;"></div>
	<div class="event rooms" style="--event-height:4; --beat:1; --y:2; --event-x:2; --event-y:0;"></div>
	<div class="event sounds" style="--beat:4; --y:2; --event-x:3; --event-y:3;"><div class="condition-false"></div></div>
	<div class="event actions" style="--beat:4; --y:3; --event-x:3; --event-y:0;"></div>
	<div class="beat" style="--tick:2; --beat:2; --y:4;"></div>
	<div class="event actions" style="--beat:1; --y:6; --event-x:5; --event-y:0;"></div>
	<div class="event sounds" style="--beat:4; --y:6; --event-x:7; --event-y:3;"></div>
	<div class="event sounds" style="--beat:4; --y:7; --event-x:6; --event-y:3;"></div>
	<div class="event decorations" style="--beat:7; --y:2; --event-x:0; --event-y:2;"></div>
	<div class="event actions" style="--beat:7; --y:3; --event-x:4; --event-y:1;"><div class="condition-true"></div></div>
	<div class="event decorations" style="--beat:7; --y:4; --event-x:0; --event-y:1;"></div>
	<div class="event sounds" style="--beat:7; --y:5; --event-x:9; --event-y:3;"></div>
	<div class="event actions" style="--beat:7; --y:6; --event-x:2; --event-y:1;"></div>
	<div class="event decorations" style="--beat:10; --y:2; --event-x:1; --event-y:0;"></div>
	<div class="event actions" style="--beat:10; --y:3; --event-x:8; --event-y:0;"></div>
	<div class="event decorations" style="--beat:10; --y:4; --event-x:0; --event-y:3;"></div>
	<div class="event rows" style="--beat:10; --y:5; --event-x:1; --event-y:0;"></div>
	<div class="event sounds" style="--beat:9; --y:6; --event-x:1; --event-y:0;"><div class="tag"></div></div>
	<div class="event actions" style="--beat:12; --y:1; --event-x:6; --event-y:2;"><div class="condition-both"></div></div>
	<div class="event actions" style="--beat:12; --y:2; --event-x:3; --event-y:1;"></div>
	<div class="event actions" style="--beat:12; --y:3; --event-x:5; --event-y:1;"></div>
	<div class="event rooms" style="--beat:13; --y:4; --event-x:3; --event-y:1;"></div>
	<div class="event actions" style="--beat:13; --y:5; --event-x:5; --event-y:3;"></div>
	<div class="event sounds" style="--beat:14; --y:6; --event-x:6; --event-y:1;"></div>
	<div class="event actions" style="--beat:14; --y:7; --event-x:4; --event-y:3;"></div>
	<div class="event sounds" style="--beat:15; --y:4; --event-x:8; --event-y:3;"></div>
	<div class="event actions" style="--beat:15; --y:5; --event-x:5; --event-y:2;"><div class="condition-both"></div></div>
	<div class="event actions" style="--beat:16; --y:1; --event-x:0; --event-y:1;"></div>
	<div class="event actions" style="--beat:16; --y:2; --event-x:2; --event-y:3;"></div>
	<div class="event actions" style="--beat:16; --y:3; --event-x:1; --event-y:1;"></div>
	<div class="event sounds" style="--beat:18; --y:7; --event-x:10; --event-y:0;"></div>
	<div class="event actions" style="--beat:19; --y:7; --event-x:1; --event-y:3;"></div>
	<div class="event sounds" style="--event-width:3; --beat:18; --y:3; --event-x:11; --event-y:1;"><div class="condition-true"></div></div>
	<div class="event sounds" style="--event-width:2; --beat:20; --y:7; --event-x:0; --event-y:3;"></div>
	<div class="event sounds" style="--beat:20; --y:4; --event-x:14; --event-y:1;"></div>
	<div class="event rooms" style="--beat:20; --y:5; --event-x:7; --event-y:3;"></div>
	<div class="event actions" style="--beat:20; --y:6; --event-x:2; --event-y:2;">	</div>
	<div class="event actions" style="--beat:23; --y:4; --event-x:3; --event-y:3;"></div>
	<div class="event sounds" style="--event-width:3; --beat:23; --y:5; --event-x:11; --event-y:0;"></div>
	<div class="event sounds" style="--beat:23; --y:6; --event-x:2; --event-y:2;"></div>
	<div class="event sounds" style="--beat:24; --y:3; --event-x:5; --event-y:3;"></div>
	<div class="event actions" style="--beat:24; --y:7; --event-x:6; --event-y:3;"></div>
	<div class="event actions" style="--beat:25; --y:3; --event-x:10; --event-y:3;"><div class="tag"></div></div>
	<div class="beat" style="--beat:25; --y:7;">
		<div class="row-xs">
			<div></div>
			<div class="x"></div>
			<div class="x"></div>
			<div></div>
			<div class="x"></div>
			<div></div>
		</div>
	</div>
		<div class="event group" style="--group-beat:20; --group-outline:#60e34523;">
		<div class="event actions" style="--event-width:0.5; --event-x:6; --event-y:1;"></div>
		<div class="beat" style="--beat:0.5; --pulse:7;">
			<div class="pulse freetime"></div>
		</div>
	</div>
	<div class="event actions" style="--beat:26; --y:4; --event-x:1; --event-y:2;"></div>
	<div class="event actions" style="--beat:26; --y:5; --event-x:3; --event-y:2;"></div>
	<div class="event rooms" style="--event-height:4; --beat:28; --y:3; --event-x:1; --event-y:0;"></div>
	<div class="event actions" style="--beat:29; --y:7; --event-x:4; --event-y:0;"></div>
	<div class="event actions" style="--beat:30; --y:3; --event-x:2; --event-y:0;"></div>
	<div class="event sounds" style="--beat:30; --y:4; --event-x:2; --event-y:3;"><div class="condition-both"></div></div>
	<div class="event rooms" style="--beat:30; --y:5; --event-x:3; --event-y:0;"><div class="tag"></div></div>
	<div class="event actions" style="--beat:30; --y:6; --event-x:1; --event-y:0;"><div class="tag"></div></div>
	<div class="event actions" style="--beat:31; --y:7; --event-x:2; --event-y:1;"></div>
	<div class="event sounds" style="--beat:32; --y:3; --event-x:4; --event-y:3;"></div>
	<div class="event sounds" style="--beat:32; --y:4; --event-x:6; --event-y:3;"></div>
	<div class="event rooms" style="--beat:32; --y:5; --event-x:7; --event-y:2;"></div>
	<div class="event actions" style="--beat:32; --y:6; --event-x:7; --event-y:1;"></div>
</div>

# RDView 参考文档

## 界面

默认为 352px * 198px 的黑屏。

<div class="RDRooms"></div>

- `--scale` 缩放。

<div class="RDRooms" style="--scale:0.5;"></div>

- `room` 图层/房间。
	- `*` 任何元素。
		- `--position-x` 元素水平位移。
		- `--position-y` 元素垂直位移。
		- `--angle` 元素旋转角度。

<div class="RDRooms">
	<div class="room" style=" --index:1;">
		<img src="./layer1.png" style="--position-x:0px; --position-y:0px;">
	</div>
	<div class="room" style=" --index:2;">
		<img src="./layer2.png" style="--position-x:20px; --position-y:20px; --angle:10;">
	</div>
	<div class="room" style=" --index:3;">
		<img src="./layer3.png" style="--position-x:300px; --position-y:120px; --angle:-40;">
	</div>
</div>

## 网格

默认为 4 行 8 列的网格。  

<div class="RDView"></div>

**超出网格的内容仍会显示。**

- `--row` 单元格行数。  
- `--column` 单元格列数。  

<div class="RDView" style="--row:3;--column:5;"><div class="event actions"></div><div class="event decorations" style="--beat:4;--y:2"></div></div>

- `--scale` 缩放。  

<div class="RDView" style="--scale:0.5"><div class="event actions"></div><div class="event decorations" style="--beat:7;--y:3"></div></div>

- `center` 居中。  

<div class="RDView center"><div class="event actions"></div><div class="event decorations" style="--beat:7;--y:3"></div></div>

- `transparent` 隐藏背景。  

<div class="RDView transparent"><div class="event actions"></div><div class="event decorations" style="--beat:7;--y:3"></div></div>

- `inline` （`<span>`）在行内显示。（目前不支持组件）  

链接到<a href="#"><span class="RDView inline" style="--row:1; --column:3; --scale:0.5;"><span class="event actions"></span><span class="event decorations" style="--beat:2"></span></span>本文档</a>。

- `lines` 小节数。  
	- `--line-count` 个数。
	- `--beat` 小节数的起始节拍。
	- `--cpb` 每个小节的节拍数。
	- 需要添加 `--line-count` 个 `<div>`。

<div class="RDView"><div class="lines" style="--line-count:3; --cpb:3;"><div>1</div><div>2</div><div>3</div></div></div>

- `playhead` 播放头。
	- `--beat` 播放头的位置。

<div class="RDView"><div class="playhead" style="--beat:2;"></div></div>

## 节拍 `beat`
默认为 tick 为 1 的二拍子。  
可以被点击。  

<div class="RDView" style="--row:2;--column:2;">
	<div class="beat"></div>
</div>

- `--beat` 列数/节拍数，0-base。  
- `--y` 行数，0-base。  
- `--offset-beat` 鼠标点击时的列数/节拍数，0-base。  
- `--offset-y` 鼠标点击时的行数，0-base。  
- `--hue` 事件的色调偏移。  
- `--brightness` 事件的亮度。
- `--grayscale` 事件的灰度。
- `--tick` 拍长。

<div class="RDView" style="--row:3;--column:4;">
	<div class="beat" style="--beat:0.5; --y:1; --tick:2.5; --hue:120; --brightness:200; --grayscale:100;"></div>
</div>

- `freezeshot` 冰冻拍。
	- `--interval` 间隔。
	- `--delay` 延迟。
- `burnshot` 灼热拍。
	- `--interval` 间隔。
- `skipshot` 跳过拍。
- `subdivision` 细分拍。
	- `--subdivision` 细分个数。
	- 需要添加 (`--subdivision` - 1) 个 `<div>`。
- `classybeat` 七拍子。
	- `--swing` 摇摆拍。
	- 需要添加 6 个 `<div>`。
- `holdbeat` 长按拍。
	- `--hold` 长按。
- `add freetime` 添加自由时长节拍。
	- `--pulse` 递进。
- `pulse freetime` 脉动自由时长节拍。
	- `--pulse` 递进。
	- `<`,`>`,`x` 分别为 `--pulse:8;`,`--pulse:9`,`--pulse:10`。
- `row-xs` 不可见拍子设置。
	- `x` 不可见拍子。
	- 需要添加 6 个 `<div>`，其中 `class="x"` 的即为不可见拍子。
- `wave` 设置单发波。
- `condition-true` 条件-真。
- `condition-false` 条件-假。
- `condition-both` 条件-皆有。
- `tag` 标签。

<div class="RDView" style="--row:10;--column:8;">
	<div class="beat" style="--beat:1; --y:0; --tick:2; --interval:3; --delay: 0.5;">
		<div class="freezeshot"></div>
	</div>
	<div class="beat" style="--beat:5; --y:0; --tick:0.5; --interval:1.5;">
		<div class="burnshot"></div>
	</div>
	<div class="beat" style="--beat:1; --y:1; --tick:1;">
		<div class="skipshot"></div>
	</div>
	<div class="beat" style="--beat:5; --y:1; --tick:1; --subdivision:3;">
		<div class="subdivision">
			<div></div>
			<div></div>
		</div>
	</div>
	<div class="beat" style="--beat:1; --y:2; --tick:6; --swing:0.5;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
	</div>
	<div class="beat" style="--beat:1; --y:3; --tick:3; --hold:1.5;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--beat:1; --y:4;">
		<div class="condition-true"></div>
	</div>
	<div class="beat" style="--beat:3; --y:4;">
		<div class="condition-false"></div>
	</div>
	<div class="beat" style="--beat:5; --y:4; --pulse:2; --hold:2;">
		<div class="pulse freetime"></div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--beat:1; --y:5;">
		<div class="condition-both"></div>
	</div>
	<div class="beat" style="--beat:3; --y:5;">
		<div class="tag"></div>
	</div>
	<div class="beat" style="--beat:5; --y:5; --pulse:7; --hold:3;">
		<div class="add freetime"></div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--beat:1; --y:6; --pulse:7; --hold:3;">
		<div class="row-xs">
			<div></div>
			<div class="x"></div>
			<div class="x"></div>
			<div></div>
			<div class="x"></div>
			<div class="x"></div>
		</div>
	</div>
	<div class="beat" style="--beat:5; --y:6; --pulse:7; --hold:3;">
		<div class="wave"></div>
	</div>
</div>

## 其他事件 `event`
可以被点击。  

- `sounds` 声音事件。  
对应图片文件 `/assets/events/sounds.png`。
- `rows` 轨道事件。  
对应图片文件 `/assets/events/actions.png`。
- `actions` 动作事件。  
对应图片文件 `/assets/events/actions.png`。
- `decorations` 精灵事件。  
对应图片文件 `/assets/events/decorations.png`。
- `rooms` 房间事件。  
对应图片文件 `/assets/events/rooms.png`。
- `custom` 自定义事件。  
对应图片文件 `/assets/events/custom.png`。

<div class="RDView" style="--row:7;--column:2;">
	<div class="event sounds"></div>
	<div class="event rows" style="--y:1;"></div>
	<div class="event actions" style="--y:2;"></div>
	<div class="event decorations" style="--y:3;"></div>
	<div class="event rooms" style="--y:4;"></div>
	<div class="event custom" style="--y:5;"></div>
</div>

- `--beat` 列数/节拍数，0-base。  
- `--y` 行数，0-base。  
- `--hue` 事件的色调偏移。  
- `--brightness` 事件的亮度。
- `--grayscale` 事件的灰度。
- `--offset-beat` 鼠标点击时向右偏移的列数/节拍数，0-base。  
- `--offset-y` 鼠标点击时向下偏移的行数，0-base。  
- `--offset-hue` 鼠标点击时事件的色调偏移。  
- `--offset-brightness` 鼠标点击时事件的亮度。
- `--offset-grayscale` 鼠标点击时事件的灰度。
- `--event-x` 截取对应图片文件中指定列的事件。
- `--event-y` 截取对应图片文件中指定行的事件。
- `--event-width` 截取事件的宽度。
- `--event-height` 截取事件的高度。

<div class="RDView" style="--row:8;--column:7;">
	<div class="event sounds" style="--beat:1; --y:1; --offset-beat:1; --offset-y:2; --event-width:5; --event-x:10; --event-y:2; --hue:240; --brightness:80;"></div>
	<div class="event rooms" style="--beat:1; --y:3; --offset-beat:2; --offset-y:1; --event-height:4; --event-x:1; --hue:250; --brightness:80;"></div>
</div>

- `group` 事件组。  
可嵌套其他事件。  
	- `--group-beat` 列数/节拍数，0-base。  
	- `--group-y` 行数，0-base。  
	- `--group-width` 事件组的宽度。
	- `--group-height` 事件组的高度。
	- `--group-hue` 事件组的色调偏移。  
	- `--group-brightness` 事件组的亮度。
	- `--group-grayscale` 事件组的灰度。
	- `--group-offset-beat` 鼠标点击时向右偏移的列数/节拍数，0-base。  
	- `--group-offset-y` 鼠标点击时向下偏移的行数，0-base。  
	- `--group-offset-hue` 鼠标点击时事件组的色调偏移。  
	- `--group-offset-brightness` 鼠标点击时事件组的亮度。
	- `--group-offset-grayscale` 鼠标点击时事件组的灰度。  
	- `--group-outline` 外边框颜色。  
如果需要给此元素添加属性，请初始化所有子元素的具有相同名称的属性。

<div class="RDView" style="--row:3;--column:3;">
	<div class="event group" style="--group-width:2.5; --group-height:2; --group-offset-beat:5; --group-offset-y:-1; --group-outline: #00ffff">
		<div class="event sounds" style="--event-height:1;--event-x:5;"></div>
		<div class="beat" style="--y:1; --tick:2.5;"></div>
	</div>
</div>

- `condition-true` 条件-真。  
- `condition-false` 条件-假。  
- `condition-both` 条件-皆有。  
- `tag` 标签。  

<div class="RDView" style="--row:5;--column:2;">
	<div class="event sounds">
		<div class="condition-true"></div>
	</div>
	<div class="event actions" style="--y:1;">
		<div class="condition-false"></div>
	</div>
	<div class="event decorations" style="--y:2;">
		<div class="condition-both"></div>
	</div>
	<div class="event rooms" style="--y:3;">
		<div class="tag"></div>
	</div>
</div>

## 其他组件

- `--pulse` 脉冲。  
- `--hit` 击拍。  
- `--cross` 十字。  

<div class="RDView" style="--row:2;--column:3;">
	<div class="pulse"></div>
	<div class="hit" style="--beat:1;"></div>
	<div class="cross" style="--beat:2;"></div>
</div>

## 描述 `description`  
事件都可以添加描述框。  
鼠标悬浮在事件上以展示描述框内容。

<div class="RDView" style="--row:4;--column:10;">
	<div class="event group" style="--group-width:2; --group-height:2; --group-y:1; --group-offset-beat:2; --group-offset-grayscale:50; --group-outline:#d8243378;">
		<div class="event sounds" style="--y:1; --event-x:3;">
			<div class="description"><br>在循环节奏型的开始添加护士语音事件“Get”。</div>
		</div>
		<div class="event sounds" style="--beat:1.5; --y:1; --event-x:4;">
			<div class="description"><br>在二拍子的落拍点添加护士语音事件“Set”。</div>
		</div>
		<div class="event sounds" style="--beat:2; --y:1; --event-x:5; --hue:90;">
			<div class="description"><br>在循环节奏型的结束添加护士语音事件“Go”。</div>
		</div>
		<div class="cross" style="--y:-1;"></div>
		<div class="pulse"></div>
		<div class="cross" style="--beat:1.5;--y:-1;"></div>
		<div class="hit" style="--beat:1.5;"></div>
		<div class="cross" style="--beat:2;--y:-1;"></div>
		<div class="description">这是一个护士提示组。</div>
	</div>
	<div class="beat" style="--beat:2;--y:0;--tick:1.5;"></div>
	<div class="beat" style="--beat:4;--y:0;--tick:1.5;"></div>
	<div class="beat" style="--beat:4.5;--y:0;--tick:1;"></div>
	<div class="beat" style="--beat:6;--y:0;--tick:1.5;"></div>
	<div class="beat" style="--beat:9;--y:0;--tick:0.5;"></div>
</div>

- `--width` 宽度。单位为 28px（即格子宽度）。
- `line` 一行。  
	- `--box-count` 需要均分排布的元素个数。  
	忽略行首的 `text` 元素。
	- `--icon-count` 需要均分排布的图标个数。  
	仅在 `line` 内部的最末尾有 `icon` 元素时有效。
	- `text` 黑色描边风格的矢量文本。  
		- `middle` 文本居中。
		- `hoverable` 鼠标悬浮在文本上会变成主题色。
		- `f-gray` 文字呈现灰色。
		- `highlight` 主题色文本。
	- `box` 文本框。  
		- `input` 输入样式的文本框效果。
			- `--tips` 文本框前缀。
			- `middle` 文本居中。
			- `f-gray` 文字呈现灰色。
			- `b-black` 背景呈现深灰色。
			- `highlight` 主题色文本。
		- `scroll` 滑动条。
			- `point` 滑动条上的点。
				- `--scroll` 滑动条上的点所处位置百分比。
		- `button` 按钮样式的文本框效果。
			- `middle` 文本居中。
			- `active` 激活的按钮文本框效果。
			- `b-gray` 背景呈现灰色。
			- `highlight` 主题色文本。
		- `select` 选择框样式的文本框效果。
			- `list` 下拉列表。
				- `p.selected` 选中状态效果。
	- `icon` 末尾的图标。
		- `file` 文件图标。
		- `wrench` 扳手图标。

<div class="RDView" style="--row:3;--column:4;">
	<div class="event sounds" style="--event-width:2; --event-y:3;">
		<div class="description" style="--width:10;">可以在这里编写任何内容。
			<div class="line" style="--icon-count:2;">
				<div class="box input middle b-black" contenteditable="true">sndOrientalTechno</div>
				<div class="icon file"></div>
				<div class="icon wrench"></div>
			</div>
			<div class="line">
				<p class="text">BPM</p><div class="box input" contenteditable="true">100</div>
			</div>
			<div class="line">
				<div class="box button middle" contenteditable="true">BPM计算</div>
			</div>
			<div class="line disable-grid">
				<p class="text middle">点击按钮开始。</p>
			</div>
		</div>
	</div>
	<div class="beat" style="--beat:1;--y:2;--tick:3;--swing:0.25;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="description" style="--width:10;">
			<div class="line" style="--box-count: 2;">
				<p class="text">拍长:</p>
				<div class="box input middle" contenteditable="true">0.5</div>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="text">摇摆:</p>
				<div class="box input middle" contenteditable="true">0.25</div>
				<div class="scroll" style="--scroll:25;">
					<div class="point"></div>
				</div>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="text">按下时间:</p>
				<div class="box input middle" contenteditable="true">0</div>
				<p class="text">beats</p>
			</div>
			<div class="line">
				<p class="box button middle b-gray">切换为<span class="highlight">X字拍子设置</span></p>
			</div>
			<div class="line">
				<p class="box button middle b-gray">分解为<span class="highlight">自由时长节拍</span></p>
			</div>
		</div>
	</div>
	<div class="event actions" style="--beat:2; --y:1; --event-x:2; --event-y:2;">
		<div class="description" style="--width:12;">同样也可以在这里编写任何内容。
			<div class="line">
				<p class="text">轨道:</p><div class="box select">1.武士（1号房间）<div class="list">
					<p class="selected">1.武士（1号房间）</p>
					<p>2.武士（1号房间）</p>
					<p>3.武士（1号房间）</p>
					<p>4.武士（1号房间）</p>
					<p>5.武士（2号房间）</p>
					<p>6.武士（2号房间）</p>
				</div></div>
			</div>
			<div class="line">
				<p class="text">目标:</p>
			</div>
			<div class="line" style="--box-count: 3;">
				<p class="box button active middle">整行</p>
				<p class="box button middle">角色</p>
				<p class="box button middle">心</p>
			</div>
			<div class="line">
				<p class="text">自定义位置</p>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="box button active middle">开启</p>
				<p class="box button middle">关闭</p>
			</div>
			<div class="line" style="--box-count: 3;">
				<p class="text hoverable">位置:</p>
				<p class="box input f-gray" contenteditable="true" style="--tips:'X:'">--</p>
				<p class="box input" contenteditable="true" style="--tips:'Y:'">50</p>
				<p class="text">%</p>
			</div>
			<div class="line" style="--box-count: 3;">
				<p class="text hoverable">大小:</p>
				<p class="box input" contenteditable="true" style="--tips:'X:'">100</p>
				<p class="box input" contenteditable="true" style="--tips:'Y:'">100</p>
				<p class="text">%</p>
			</div>
			<div class="line">
				<p class="text hoverable f-gray">角度: 关闭</p>
			</div>
			<div class="line">
				<p class="text hoverable f-gray">轴点: 关闭</p>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="text">动画时长:</p>
				<p class="box input" contenteditable="true">1</p>
				<p class="text">节拍</p>
			</div>
			<div class="line">
				<p class="text">缓速:</p><div class="box select">Linear<div class="list">
					<p class="selected">Linear</p>
					<p>InSine</p>
					<p>OutSine</p>
					<p>InOutSine</p>
					<p>InQuad</p>
					<p>OutQuad</p>
					<p>InOutQuad</p>
					<p>InCubic</p>
					<p>OutCubic</p>
					<p>InOutCubic</p>
					<p>InQuart</p>
					<p>OutQuart</p>
					<p>InOutQuart</p>
					<p>InQuint</p>
					<p>OutQuint</p>
					<p>InOutQuint</p>
					<p>InExpo</p>
					<p>OutExpo</p>
					<p>InOutExpo</p>
					<p>InCirc</p>
					<p>OutCirc</p>
					<p>InOutCirc</p>
					<p>InElastic</p>
					<p>OutElastic</p>
					<p>InOutElastic</p>
					<p>InBack</p>
					<p>OutBack</p>
					<p>InOutBack</p>
					<p>InBounce</p>
					<p>OutBounce</p>
					<p>InOutBounce</p>
				</div></div>
			</div>
		</div>
	</div>
</div>
