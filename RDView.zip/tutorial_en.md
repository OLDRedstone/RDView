<link rel="stylesheet" href="RDView.css">

<div class="RDView" style="--row:9; --column:33; --scale:1;">
	<div class="lines" style="--line-count:4; --cpb:6;"><div>1</div><div>2</div><div>3</div><div>4</div></div>
	<div class="lines" style="--beat: 23; --line-count:2; --cpb:5;"><div>5</div><div>6</div></div>
	<div class="playhead" style="--beat:12;"></div>
	<div class="event rooms" style="--beat:0; --y:1; --event-x:0; --event-y:1;"><div class="condition-true"></div></div>
	<div class="beat" style="--tick:3; --beat:6; --y:1; --swing:0.25; --hold:1;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="tag"></div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--tick:1; --beat:6; --y:7; --interval:3; --delay:0.5;">
		<div class="freezeshot"></div>
		<div class="skipshot"></div>
	</div>
	<div class="beat" style="--tick:1; --beat:3; --y:5; --interval:2;">
		<div class="burnshot"></div>
	</div>
	<div class="beat" style="--tick:2; --beat:0; --y:7; --subdivision:2;">
		<div class="subdivision">
			<div></div>
		</div>
	</div>
	<div class="beat" style="--tick:3; --beat:1; --y:1;"></div>
	<div class="event rooms" style="--event-height:4; --beat:1; --y:2; --event-x:2; --event-y:0;"></div>
	<div class="event sounds" style="--beat:4; --y:2; --event-x:3; --event-y:3;"><div class="condition-false"></div></div>
	<div class="event actions" style="--beat:4; --y:3; --event-x:3; --event-y:0;"></div>
	<div class="beat" style="--tick:2; --beat:2; --y:4;"></div>
	<div class="event actions" style="--beat:1; --y:6; --event-x:5; --event-y:0;"></div>
	<div class="event sounds" style="--beat:4; --y:6; --event-x:7; --event-y:3;"></div>
	<div class="event sounds" style="--beat:4; --y:7; --event-x:6; --event-y:3;"></div>
	<div class="event decorations" style="--beat:7; --y:2; --event-x:0; --event-y:2;"></div>
	<div class="event actions" style="--beat:7; --y:3; --event-x:4; --event-y:1;"><div class="condition-true"></div></div>
	<div class="event decorations" style="--beat:7; --y:4; --event-x:0; --event-y:1;"></div>
	<div class="event sounds" style="--beat:7; --y:5; --event-x:9; --event-y:3;"></div>
	<div class="event actions" style="--beat:7; --y:6; --event-x:2; --event-y:1;"></div>
	<div class="event decorations" style="--beat:10; --y:2; --event-x:1; --event-y:0;"></div>
	<div class="event actions" style="--beat:10; --y:3; --event-x:8; --event-y:0;"></div>
	<div class="event decorations" style="--beat:10; --y:4; --event-x:0; --event-y:3;"></div>
	<div class="event rows" style="--beat:10; --y:5; --event-x:1; --event-y:0;"></div>
	<div class="event sounds" style="--beat:9; --y:6; --event-x:1; --event-y:0;"><div class="tag"></div></div>
	<div class="event actions" style="--beat:12; --y:1; --event-x:6; --event-y:2;"><div class="condition-both"></div></div>
	<div class="event actions" style="--beat:12; --y:2; --event-x:3; --event-y:1;"></div>
	<div class="event actions" style="--beat:12; --y:3; --event-x:5; --event-y:1;"></div>
	<div class="event rooms" style="--beat:13; --y:4; --event-x:3; --event-y:1;"></div>
	<div class="event actions" style="--beat:13; --y:5; --event-x:5; --event-y:3;"></div>
	<div class="event sounds" style="--beat:14; --y:6; --event-x:6; --event-y:1;"></div>
	<div class="event actions" style="--beat:14; --y:7; --event-x:4; --event-y:3;"></div>
	<div class="event sounds" style="--beat:15; --y:4; --event-x:8; --event-y:3;"></div>
	<div class="event actions" style="--beat:15; --y:5; --event-x:5; --event-y:2;"><div class="condition-both"></div></div>
	<div class="event actions" style="--beat:16; --y:1; --event-x:0; --event-y:1;"></div>
	<div class="event actions" style="--beat:16; --y:2; --event-x:2; --event-y:3;"></div>
	<div class="event actions" style="--beat:16; --y:3; --event-x:1; --event-y:1;"></div>
	<div class="event sounds" style="--beat:18; --y:7; --event-x:10; --event-y:0;"></div>
	<div class="event actions" style="--beat:19; --y:7; --event-x:1; --event-y:3;"></div>
	<div class="event sounds" style="--event-width:3; --beat:18; --y:3; --event-x:11; --event-y:1;"><div class="condition-true"></div></div>
	<div class="event sounds" style="--event-width:2; --beat:20; --y:7; --event-x:0; --event-y:3;"></div>
	<div class="event sounds" style="--beat:20; --y:4; --event-x:14; --event-y:1;"></div>
	<div class="event rooms" style="--beat:20; --y:5; --event-x:7; --event-y:3;"></div>
	<div class="event actions" style="--beat:20; --y:6; --event-x:2; --event-y:2;">	</div>
	<div class="event actions" style="--beat:23; --y:4; --event-x:3; --event-y:3;"></div>
	<div class="event sounds" style="--event-width:3; --beat:23; --y:5; --event-x:11; --event-y:0;"></div>
	<div class="event sounds" style="--beat:23; --y:6; --event-x:2; --event-y:2;"></div>
	<div class="event sounds" style="--beat:24; --y:3; --event-x:5; --event-y:3;"></div>
	<div class="event actions" style="--beat:24; --y:7; --event-x:6; --event-y:3;"></div>
	<div class="event actions" style="--beat:25; --y:3; --event-x:10; --event-y:3;"><div class="tag"></div></div>
	<div class="beat" style="--beat:25; --y:7;">
		<div class="row-xs">
			<div></div>
			<div class="x"></div>
			<div class="x"></div>
			<div></div>
			<div class="x"></div>
			<div></div>
		</div>
	</div>
		<div class="event group" style="--group-beat:20; --group-outline:#60e34523;">
		<div class="event actions" style="--event-width:0.5; --event-x:6; --event-y:1;"></div>
		<div class="beat" style="--beat:0.5; --pulse:7;">
			<div class="pulse freetime"></div>
		</div>
	</div>
	<div class="event actions" style="--beat:26; --y:4; --event-x:1; --event-y:2;"></div>
	<div class="event actions" style="--beat:26; --y:5; --event-x:3; --event-y:2;"></div>
	<div class="event rooms" style="--event-height:4; --beat:28; --y:3; --event-x:1; --event-y:0;"></div>
	<div class="event actions" style="--beat:29; --y:7; --event-x:4; --event-y:0;"></div>
	<div class="event actions" style="--beat:30; --y:3; --event-x:2; --event-y:0;"></div>
	<div class="event sounds" style="--beat:30; --y:4; --event-x:2; --event-y:3;"><div class="condition-both"></div></div>
	<div class="event rooms" style="--beat:30; --y:5; --event-x:3; --event-y:0;"><div class="tag"></div></div>
	<div class="event actions" style="--beat:30; --y:6; --event-x:1; --event-y:0;"><div class="tag"></div></div>
	<div class="event actions" style="--beat:31; --y:7; --event-x:2; --event-y:1;"></div>
	<div class="event sounds" style="--beat:32; --y:3; --event-x:4; --event-y:3;"></div>
	<div class="event sounds" style="--beat:32; --y:4; --event-x:6; --event-y:3;"></div>
	<div class="event rooms" style="--beat:32; --y:5; --event-x:7; --event-y:2;"></div>
	<div class="event actions" style="--beat:32; --y:6; --event-x:7; --event-y:1;"></div>
</div>

# RDView reference document

## screen

Defaults to a black screen of 352px * 198px.

<div class="RDRooms"></div>

- `--scale` Scale.

<div class="RDRooms" style="--scale:0.5;"></div>

- `room` Layers/Rooms.
	- `*` Any element.
		- `--position-x` Elemental horizontal displacement.
		- `--position-y` Element vertical displacement.
		- `--angle` Element rotation angle.

<div class="RDRooms">
	<div class="room" style=" --index:1;">
		<img src="./images/layer1.png" style="--position-x:0px; --position-y:0px;">
	</div>
	<div class="room" style=" --index:2;">
		<img src="./images/layer2.png" style="--position-x:20px; --position-y:20px; --angle:10;">
	</div>
	<div class="room" style=" --index:3;">
		<img src="./images/layer3.png" style="--position-x:300px; --position-y:120px; --angle:-40;">
	</div>
</div>

## Grid

Defaults to a grid of 4 rows and 8 columns.

<div class="RDView"></div>

**Anything beyond the grid will still be displayed.**

- `--row` Number of cell rows.  
- `--column` Number of cell columns.  

<div class="RDView" style="--row:3;--column:5;"><div class="event actions"></div><div class="event decorations" style="--beat:4;--y:2"></div></div>

- `--scale` Scale.  

<div class="RDView" style="--scale:0.5"><div class="event actions"></div><div class="event decorations" style="--beat:7;--y:3"></div></div>

- `center` Centering.  

<div class="RDView center"><div class="event actions"></div><div class="event decorations" style="--beat:7;--y:3"></div></div>

- `transparent` Hide the background.  

<div class="RDView transparent"><div class="event actions"></div><div class="event decorations" style="--beat:7;--y:3"></div></div>

- `inline` (`<span>`) Display in line. (Components are not currently supported)  

Link to <a href="#"><span class="RDView inline" style="--row:1; --column:3; --scale:0.5;"><span class="event actions"></span><span class="event decorations" style="--beat:2"></span></span> this document</a>.

- `lines` Number of bars.  
	- `--line-count` Number of individuals.
	- `--beat` Starting beat of the bar count.
	- `--cpb` The number of beats per bar.
	- Need to add `--line-count` individual `<div>`.

<div class="RDView"><div class="lines" style="--line-count:3; --cpb:3;"><div>1</div><div>2</div><div>3</div></div></div>

- `playhead` Playhead.
	- `--beat` The position of the playhead.

<div class="RDView"><div class="playhead" style="--beat:2;"></div></div>

## Beat `beat`
Defaults to a oneshot beat with a tick of 1.  
Can be clicked.  

<div class="RDView" style="--row:2;--column:2;">
	<div class="beat"></div>
</div>

- `--beat` Number of columns/beats, 0-base.  
- `--y` Number of rows, 0-base.  
- `--offset-beat` Number of columns/beats at mouse click, 0-base.  
- `--offset-y` Number of rows at mouse click, 0-base.  
- `--hue` The hue offset of the event.  
- `--brightness` The brightness of the event.
- `--grayscale` The grayscale of the event.
- `--tick` The tick of the event.

<div class="RDView" style="--row:3;--column:4;">
	<div class="beat" style="--beat:0.5; --y:1; --tick:2.5; --hue:120; --brightness:200; --grayscale:100;"></div>
</div>

- `freezeshot` Freezeshot.
	- `--interval` Interval.
	- `--delay` Delay.
- `burnshot` Burnshot.
	- `--interval` Interval.
- `skipshot` Skipshot.
- `subdivision` Subdivision.
	- `--subdivision` Subdivision number.
	- Need to add (`-subdivision` - 1) `<div>`.
- `classybeat` Classybeat.
	- `--swing` Swing.
	- 6 `<div>`s need to be added.
- `holdbeat` Holdbeat.
	- `--hold` The length of the hold.
- `add freetime` Add free time beat.
	- `--pulse` Pulse.
- `pulse freetime` Pulse free time beat.
	- `--pulse` Pulse.
	- `<`,`>`,`x` are `--pulse:8;`,`--pulse:9`,`--pulse:10`, respectively.
- `row-xs` Set row Xs.
	- `x` Row X.
	- Need to add 6 `<div>`, where `class="x"` is the X beat.
- `wave` Set oneshot wave.
- `condition-true` Condition true.
- `condition-false` Condition false.
- `condition-both` Condition both.
- `tag` Tag.

<div class="RDView" style="--row:10;--column:8;">
	<div class="beat" style="--beat:1; --y:0; --tick:2; --interval:3; --delay: 0.5;">
		<div class="freezeshot"></div>
	</div>
	<div class="beat" style="--beat:5; --y:0; --tick:0.5; --interval:1.5;">
		<div class="burnshot"></div>
	</div>
	<div class="beat" style="--beat:1; --y:1; --tick:1;">
		<div class="skipshot"></div>
	</div>
	<div class="beat" style="--beat:5; --y:1; --tick:1; --subdivision:3;">
		<div class="subdivision">
			<div></div>
			<div></div>
		</div>
	</div>
	<div class="beat" style="--beat:1; --y:2; --tick:6; --swing:0.5;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
	</div>
	<div class="beat" style="--beat:1; --y:3; --tick:3; --hold:1.5;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--beat:1; --y:4;">
		<div class="condition-true"></div>
	</div>
	<div class="beat" style="--beat:3; --y:4;">
		<div class="condition-false"></div>
	</div>
	<div class="beat" style="--beat:5; --y:4; --pulse:2; --hold:2;">
		<div class="pulse freetime"></div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--beat:1; --y:5;">
		<div class="condition-both"></div>
	</div>
	<div class="beat" style="--beat:3; --y:5;">
		<div class="tag"></div>
	</div>
	<div class="beat" style="--beat:5; --y:5; --pulse:7; --hold:3;">
		<div class="add freetime"></div>
		<div class="holdbeat"></div>
	</div>
	<div class="beat" style="--beat:1; --y:6; --pulse:7; --hold:3;">
		<div class="row-xs">
			<div></div>
			<div class="x"></div>
			<div class="x"></div>
			<div></div>
			<div class="x"></div>
			<div class="x"></div>
		</div>
	</div>
	<div class="beat" style="--beat:5; --y:6; --pulse:7; --hold:3;">
		<div class="wave"></div>
	</div>
</div>

## Other events `event`
Can be clicked.

- `sounds` Sound events.  
Corresponds to the image file `/assets/events/sounds.png`.
- `rows` Row events.  
Corresponds to the image file `/assets/events/actions.png`。
- `actions` Action events.  
Corresponds to the image file `/assets/events/actions.png`。
- `decorations` Decoration events.  
Corresponds to the image file `/assets/events/decorations.png`。
- `rooms` Room events.  
Corresponds to the image file `/assets/events/rooms.png`。
- `custom` Custom events.  
Corresponds to the image file `/assets/events/custom.png`。

<div class="RDView" style="--row:7;--column:2;">
	<div class="event sounds"></div>
	<div class="event rows" style="--y:1;"></div>
	<div class="event actions" style="--y:2;"></div>
	<div class="event decorations" style="--y:3;"></div>
	<div class="event rooms" style="--y:4;"></div>
	<div class="event custom" style="--y:5;"></div>
</div>

- `--beat` Number of columns/beats, 0-base.  
- `--y` Number of rows, 0-base.  
- `--hue` The hue offset of the event.  
- `--brightness` The brightness of the event.
- `--grayscale` The grayscale of the event.
- `--offset-beat` The number of columns/beats offset to the right on mouse click, 0-base.  
- `--offset-y` The number of rows offset downward on mouse click, 0-base.  
- `--offset-hue` The hue offset of the event on mouse click.  
- `--offset-brightness` The brightness of the event on mouse click.
- `--offset-grayscale` The grayscale of the event at mouse click.
- `--event-x` The event that captures the specified column in the corresponding image file.file.
- `--event-y` The event that captures the specified row in the corresponding image file.
- `--event-width` The width of the captured event.
- `--event-height` The height of the captured event.

<div class="RDView" style="--row:8;--column:7;">
	<div class="event sounds" style="--beat:1; --y:1; --offset-beat:1; --offset-y:2; --event-width:5; --event-x:10; --event-y:2; --hue:240; --brightness:80;"></div>
	<div class="event rooms" style="--beat:1; --y:3; --offset-beat:2; --offset-y:1; --event-height:4; --event-x:1; --hue:250; --brightness:80;"></div>
</div>

- `group` Group of events.  
Additional events can be nested.  
	- `--group-beat` Number of columns/beats, 0-base.  
	- `--group-y` Number of rows, 0-base.  
	- `--group-width` The width of the event group.  
	- `--group-height` The height of the event group.  
	- `--group-hue` Hue offset for the event group.  
	- `--group-brightness` The brightness of the event group.
	- `--group-grayscale` The grayscale of the event group.
	- `--group-offset-beat` The number of columns/beats offset to the right on mouse click, 0-base.  
	- `--group-offset-y` The number of rows offset downward on mouse clicks, 0-base.  
	- `--group-offset-hue` The hue offset of the event group on mouse click.  
	- `--group-offset-brightness` The brightness of the event group at mouse click.
	- `--group-offset-grayscale` The grayscale of the event group at the time of the mouse click.  
	- `--group-outline` The outer border color.  
If you need to add attributes to this element, initialize attributes with the same name for all child elements.  

<div class="RDView" style="--row:3;--column:3;">
	<div class="event group" style="--group-width:2.5; --group-height:2; --group-offset-beat:5; --group-offset-y:-1; --group-outline: #00ffff">
		<div class="event sounds" style="--event-height:1;--event-x:5;"></div>
		<div class="beat" style="--y:1; --tick:2.5;"></div>
	</div>
</div>

- `condition-true` Condition true.
- `condition-false` Condition false.
- `condition-both` Condition both.
- `tag` Tag.

<div class="RDView" style="--row:5;--column:2;">
	<div class="event sounds">
		<div class="condition-true"></div>
	</div>
	<div class="event actions" style="--y:1;">
		<div class="condition-false"></div>
	</div>
	<div class="event decorations" style="--y:2;">
		<div class="condition-both"></div>
	</div>
	<div class="event rooms" style="--y:3;">
		<div class="tag"></div>
	</div>
</div>

## Other components

- `--pulse` Pulse.  
- `--hit` Hit.  
- `--cross` Cross.  

<div class="RDView" style="--row:2;--column:3;">
	<div class="pulse"></div>
	<div class="hit" style="--beat:1;"></div>
	<div class="cross" style="--beat:2;"></div>
</div>

## Description `description`  
Events can all add description boxes.  
Hover over the event to display the description box contents.

<div class="RDView" style="--row:4;--column:10;">
	<div class="event group" style="--group-width:2; --group-height:2; --group-y:1; --group-offset-beat:2; --group-offset-grayscale:50; --group-outline:#d8243378;">
		<div class="event sounds" style="--y:1; --event-x:3;">
			<div class="description"><br>Add the nurse voice event "Get" at the beginning of the loop rhythm pattern.</div>
		</div>
		<div class="event sounds" style="--beat:1.5; --y:1; --event-x:4;">
			<div class="description"><br>Add the nurse voice event "Set" to the hit of the oneshot.</div>
		</div>
		<div class="event sounds" style="--beat:2; --y:1; --event-x:5; --hue:90;">
			<div class="description"><br>Add the nurse voice event "Go" at the end of the loop rhythm pattern.</div>
		</div>
		<div class="cross" style="--y:-1;"></div>
		<div class="pulse"></div>
		<div class="cross" style="--beat:1.5;--y:-1;"></div>
		<div class="hit" style="--beat:1.5;"></div>
		<div class="cross" style="--beat:2;--y:-1;"></div>
		<div class="description">This is a nurse cue group.</div>
	</div>
	<div class="beat" style="--beat:2;--y:0;--tick:1.5;"></div>
	<div class="beat" style="--beat:4;--y:0;--tick:1.5;"></div>
	<div class="beat" style="--beat:4.5;--y:0;--tick:1;"></div>
	<div class="beat" style="--beat:6;--y:0;--tick:1.5;"></div>
	<div class="beat" style="--beat:9;--y:0;--tick:0.5;"></div>
</div>

- `--width` Width. The unit is 28px (i.e. the width of the grid).
- `-line` A line.  
	- `--box-count` The number of elements to evenly spaced.  
	Ignore `text` elements at the beginning of a line.
	- `--icon-count` The number of icons to be evenly spaced.  
	Valid only if there is an `icon` element at the end of the `line` container.
	- `text` Black stroke style vector text.  
		- `middle` Centers the text.  
		- `hoverable` Text becomes theme color when mouse is hovered over it.
		- `f-gray` Text is rendered in gray.
		- `highlight` Text in theme color.
	- `box` Text box.  
		- `input` Input style text box effect.
			- `--tips` Text box prefix.
			- `middle` Centers the text.  
			- `f-gray` Text is rendered in gray.
			- `b-black` The background is rendered in gray.
			- `highlight` Theme color text.
		- `scroll` Slider.
			- `point` The point on the slider.
				- `-scroll` Percentage position of the point on the slider.
		- `button` Button style text box effect.
			- `middle` Centers the text.  
			- `-active` The active button text box effect.
			- `b-gray` The background is rendered in gray.
			- `highlight` Theme color text.
		- `select` Select box style text box effect.
			- `list` Drop-down list.
				- `p.selected` Selected state effect.
	- `icon` End icon.
		- `file` File icon.
		- `wrench` Wrench icon.

<div class="RDView" style="--row:3;--column:4;">
	<div class="event sounds" style="--event-width:2; --event-y:3;">
		<div class="description" style="--width:14;">Anything can be written here.
			<div class="line" style="--icon-count:2;">
				<div class="box input middle b-black" contenteditable="true">sndOrientalTechno</div>
				<div class="icon file"></div>
				<div class="icon wrench"></div>
			</div>
			<div class="line">
				<p class="text">Beats Per Minute:</p><div class="box input" contenteditable="true">100</div>
			</div>
			<div class="line">
				<div class="box button middle" contenteditable="true">Calculate BPM</div>
			</div>
			<div class="line disable-grid">
				<p class="text middle">Click to start.</p>
			</div>
		</div>
	</div>
	<div class="beat" style="--beat:1;--y:2;--tick:3;--swing:0.25;">
		<div class="classybeat">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="description" style="--width:10;">
			<div class="line" style="--box-count: 2;">
				<p class="text">Tick:</p>
				<div class="box input middle" contenteditable="true">0.5</div>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="text">Swing:</p>
				<div class="box input middle" contenteditable="true">0.25</div>
				<div class="scroll" style="--scroll:25;">
					<div class="point"></div>
				</div>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="text">Hold time:</p>
				<div class="box input middle" contenteditable="true">0</div>
				<p class="text">beats</p>
			</div>
			<div class="line">
				<p class="box button middle b-gray">Switch to <span class="highlight">Set Row Xs</span></p>
			</div>
			<div class="line">
				<p class="box button middle b-gray">Break into<span class="highlight">Free time pulse</span></p>
			</div>
		</div>
	</div>
	<div class="event actions" style="--beat:2; --y:1; --event-x:2; --event-y:2;">
		<div class="description" style="--width:12;">Likewise anything can be written here.
			<div class="line">
				<p class="text">Row:</p><div class="box select">1.Samurai (Room 1)<div class="list">
					<p class="selected">1.Samurai (Room 1)</p>
					<p>2.Samurai (Room 1)</p>
					<p>3.Samurai (Room 1)</p>
					<p>4.Samurai (Room 1)</p>
					<p>5.Samurai (Room 2)</p>
					<p>6.Samurai (Room 3)</p>
				</div></div>
			</div>
			<div class="line">
				<p class="text">Target:</p>
			</div>
			<div class="line" style="--box-count: 3;">
				<p class="box button active middle">Whole Row</p>
				<p class="box button middle">Character</p>
				<p class="box button middle">Heart</p>
			</div>
			<div class="line">
				<p class="text">Custom position:</p>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="box button active middle">On</p>
				<p class="box button middle">Off</p>
			</div>
			<div class="line" style="--box-count: 3;">
				<p class="text hoverable">Position:</p>
				<p class="box input f-gray" contenteditable="true" style="--tips:'X:'">--</p>
				<p class="box input" contenteditable="true" style="--tips:'Y:'">50</p>
				<p class="text">%</p>
			</div>
			<div class="line" style="--box-count: 3;">
				<p class="text hoverable">Scale:</p>
				<p class="box input" contenteditable="true" style="--tips:'X:'">100</p>
				<p class="box input" contenteditable="true" style="--tips:'Y:'">100</p>
				<p class="text">%</p>
			</div>
			<div class="line">
				<p class="text hoverable f-gray">Angle: Off</p>
			</div>
			<div class="line">
				<p class="text hoverable f-gray">Pivot: Off</p>
			</div>
			<div class="line" style="--box-count: 2;">
				<p class="text">Animation duration:</p>
				<p class="box input" contenteditable="true">1</p>
				<p class="text">beat</p>
			</div>
			<div class="line">
				<p class="text">Ease:</p><div class="box select">Linear<div class="list">
					<p class="selected">Linear</p>
					<p>InSine</p>
					<p>OutSine</p>
					<p>InOutSine</p>
					<p>InQuad</p>
					<p>OutQuad</p>
					<p>InOutQuad</p>
					<p>InCubic</p>
					<p>OutCubic</p>
					<p>InOutCubic</p>
					<p>InQuart</p>
					<p>OutQuart</p>
					<p>InOutQuart</p>
					<p>InQuint</p>
					<p>OutQuint</p>
					<p>InOutQuint</p>
					<p>InExpo</p>
					<p>OutExpo</p>
					<p>InOutExpo</p>
					<p>InCirc</p>
					<p>OutCirc</p>
					<p>InOutCirc</p>
					<p>InElastic</p>
					<p>OutElastic</p>
					<p>InOutElastic</p>
					<p>InBack</p>
					<p>OutBack</p>
					<p>InOutBack</p>
					<p>InBounce</p>
					<p>OutBounce</p>
					<p>InOutBounce</p>
				</div></div>
			</div>
		</div>
	</div>
</div>
